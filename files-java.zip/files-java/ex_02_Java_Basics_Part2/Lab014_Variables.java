package ex_02_Java_Basics_Part2;

public class Lab014_Variables {
    public static void main(String[] args) {

    }

    public static void main(int args) {

    }
}
