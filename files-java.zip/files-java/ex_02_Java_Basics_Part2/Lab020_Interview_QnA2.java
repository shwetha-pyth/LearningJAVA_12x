package ex_02_Java_Basics_Part2;

public class Lab020_Interview_QnA2 {
    public static void main(String[] args) {
        // int enum = 10;
        int Enum = 10;
        int a_b = 89;
//        int pramod dutta  = 89;
        int pramod$dutta = 90;
        int Lab020_Interview_QnA2 = 123;


    }
}
