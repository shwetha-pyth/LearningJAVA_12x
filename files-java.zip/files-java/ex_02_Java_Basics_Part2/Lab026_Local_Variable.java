package ex_02_Java_Basics_Part2;

public class Lab026_Local_Variable {
    public static void main(String[] args) {
        int a = 10;
        byte b = 10;
        short s = 10;
        long l = 9876543210L;
        float f = 3.14F;
        double d = 67.8987654567;
        boolean b1 = true;
        char c = 'A';
    }
}
