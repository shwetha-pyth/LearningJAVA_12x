package ex_02_Java_Basics_Part2;

public class Lab017_Variables {
    public static void main(String[] args) {

        int age = 76;
        age = age+1;
        age = 76;
        System.out.println(age);



    }
}
