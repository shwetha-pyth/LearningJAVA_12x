package ex_03_Literals;

public class Lab032_Literals_P3 {
    public static void main(String[] args) {
        int Enum = 9; // enum is keyword
        System.out.println(Enum);
    }
}
