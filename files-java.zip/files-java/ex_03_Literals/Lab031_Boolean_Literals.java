package ex_03_Literals;

public class Lab031_Boolean_Literals {
    public static void main(String[] args) {
        boolean is_married = true;
        boolean is_married_amit = false;
        // boolean is_married_amit = 123;
    }
}
